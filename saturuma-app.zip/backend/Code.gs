/**
 * ============================================================================
 * SATURUMA - SUPER-APP KEUANGAN & MANAJEMEN RUMAH TANGGA
 * "Satu Rumah, Semua Pencatatan Terintegrasi"
 * BACKEND API & GOOGLE APPS SCRIPT ENGINE (Code.gs)
 * ============================================================================
 * Fitur Lengkap & Disempurnakan:
 * - doGet(e): Handler antarmuka Single Page Application (SPA)
 * - getAppMetadata: Mengambil metadata konfigurasi, sheets, drive, budget, dan master categories
 * - Master Categories CRUD: getMasterCategories & saveMasterCategories (disimpan di PropertiesService & Config_Master)
 * - Dynamic Sheet Routing: saveTransactionToSheet, updateTransactionInSheet, deleteTransactionFromSheet
 * - getRecentEntries: Agregasi data dari seluruh sheet / sheet kategori spesifik beserta KPI & statistik
 * - extractReceiptWithAI: Ekstraksi AI Multi-Item, Diskon, Pajak & Deteksi Kategori Cerdas (Gemini 3.8 Flash)
 * - getStorageFolders & saveBase64File: Simpan foto & PDF ke Google Drive
 * - saveMonthlyBudget & saveGeminiApiKey: Pengaturan sistem
 * ============================================================================
 */

const CONFIG = {
  APP_NAME: "Saturuma",
  APP_SLOGAN: "Satu Rumah, Semua Pencatatan Terintegrasi",
  PARENT_FOLDER_NAME: "Saturuma System",
  ITEM_PHOTOS_FOLDER: "Item Photos",
  RECEIPTS_FOLDER: "Receipts",
  CONFIG_SHEET_NAME: "Config_Master",
  USERS_SHEET_NAME: "DB_Users",
  USER_COLUMNS: [
    "UserID",
    "Username",
    "PasswordHash",
    "Salt",
    "FullName",
    "Role",
    "Status",
    "CreatedAt",
    "LastLogin",
    "CustomSpreadsheetId",
    "GeminiApiKey"
  ],
  DEMO_USER: {
    username: "admin",
    password: "admin 123",
    fullName: "Administrator Saturuma",
    role: "admin"
  },
  STANDARD_COLUMNS: [
    "Timestamp",
    "Date",
    "ReceiptID",
    "Merchant",
    "ItemName",
    "SubCategory",
    "Qty",
    "Cost",
    "Discount",
    "Tax",
    "Other",
    "ItemPhotoUrl",
    "ReceiptPhotoUrl",
    "UserID"
  ],
  DEFAULT_CATEGORIES: [
    {
      id: "bayi",
      name: "Kebutuhan Bayi",
      sheetName: "DB_Bayi",
      color: "#F47174",
      icon: "fa-baby-carriage",
      subCategories: ["Popok", "Susu & Makanan", "Pakaian", "Kesehatan & Mandi", "Gear & Perlengkapan", "Mainan & Buku", "Lainnya"]
    },
    {
      id: "dapur",
      name: "Belanja Dapur & Groceries",
      sheetName: "DB_Dapur",
      color: "#10B981",
      icon: "fa-basket-shopping",
      subCategories: ["Sembako & Bumbu", "Sayur & Buah", "Daging & Ikan", "Makanan Instan & Camilan", "Minuman", "Alat Dapur", "Perlengkapan Cuci"]
    },
    {
      id: "tagihan",
      name: "Tagihan & Rutinitas Rumah",
      sheetName: "DB_Tagihan",
      color: "#3B82F6",
      icon: "fa-file-invoice-dollar",
      subCategories: ["Listrik PLN", "Air PDAM", "Internet & WiFi", "Gas Elpiji", "Iuran RT/RW & Keamanan", "Sampah & Kebersihan", "Cicilan & Sewa"]
    },
    {
      id: "tabungan",
      name: "Tabungan & Investasi",
      sheetName: "DB_Tabungan",
      color: "#A855F7",
      icon: "fa-piggy-bank",
      subCategories: ["Dana Darurat", "Tabungan Pendidikan", "Emas & Logam Mulia", "Reksadana & Saham", "Asuransi", "Tabungan Khusus"]
    },
    {
      id: "transport",
      name: "Transportasi & Kendaraan",
      sheetName: "DB_Transport",
      color: "#F59E0B",
      icon: "fa-car",
      subCategories: ["Bensin & BBM", "Tol & Parkir", "Servis & Oli", "Pajak & STNK", "Angkutan Umum / Ojol", "Cuci Kendaraan", "Sparepart"]
    }
  ]
};

/**
 * 1. HTTP GET & POST HANDLER (API GATEWAY UNTUK GITHUB PAGES & WEB APP)
 */
function doGet(e) {
  try {
    // Handler untuk pemanggilan API melalui HTTP GET (misal: ping atau status)
    if (e && e.parameter && (e.parameter.action || e.parameter.ping)) {
      if (e.parameter.ping) {
        return ContentService.createTextOutput(JSON.stringify({
          success: true,
          appName: CONFIG.APP_NAME,
          version: "2.1",
          privacyMode: "Isolated & Protected",
          message: "Backend Saturuma Google Apps Script Aktif & Siap Digunakan!"
        })).setMimeType(ContentService.MimeType.JSON);
      }
      if (e.parameter.action === "getRecentEntries") {
        const res = getRecentEntries(
          e.parameter.sheetName || "all",
          parseInt(e.parameter.limit || "500", 10),
          e.parameter.customSpreadsheetId,
          e.parameter.userId,
          false
        );
        return ContentService.createTextOutput(JSON.stringify(res)).setMimeType(ContentService.MimeType.JSON);
      }
      if (e.parameter.action === "getAppMetadata") {
        return ContentService.createTextOutput(JSON.stringify(getAppMetadata(e.parameter.customSpreadsheetId))).setMimeType(ContentService.MimeType.JSON);
      }
    }

    // Default: jika diakses langsung di browser sebagai Web App
    let htmlOutput;
    try {
      htmlOutput = HtmlService.createHtmlOutputFromFile("Index");
    } catch (notFoundErr) {
      htmlOutput = HtmlService.createHtmlOutputFromFile("index");
    }

    return htmlOutput
      .setTitle("Saturuma - Super-App Keuangan & Manajemen Rumah Tangga")
      .addMetaTag("viewport", "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover")
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  } catch (err) {
    return HtmlService.createHtmlOutput("<h3 style='font-family:sans-serif;color:#ef4444;'>Gagal memuat Saturuma: " + err.message + "</h3>");
  }
}

/**
 * HELPER: VERIFIKASI IDENTITAS PENGGUNA DARI SESI (DATA PRIVACY GUARD)
 */
function getAuthUser(sessionToken, fallbackUserId) {
  if (sessionToken) {
    const sess = validateSession(sessionToken);
    if (sess && sess.success && sess.user) {
      return sess.user;
    }
  }
  if (fallbackUserId) {
    return { userId: String(fallbackUserId).trim(), role: "member" };
  }
  return null;
}

/**
 * HTTP POST HANDLER (API GATEWAY UTAMA DARI FRONTEND GITHUB PAGES / STANDALONE)
 */
function doPost(e) {
  try {
    let requestData = {};
    if (e && e.postData && e.postData.contents) {
      try {
        requestData = JSON.parse(e.postData.contents);
      } catch (parseErr) {
        requestData = e.parameter || {};
      }
    } else if (e && e.parameter) {
      requestData = e.parameter;
    }

    const action = requestData.action;
    const args = Array.isArray(requestData.args) ? requestData.args : [];
    const sessionToken = requestData.sessionToken || (requestData.args && requestData.args.sessionToken) || "";
    const reqUserId = requestData.userId || "";
    let result = null;

    switch (action) {
      case "ping":
        result = {
          success: true,
          appName: CONFIG.APP_NAME,
          version: "2.1",
          privacyMode: "Isolated & Protected",
          message: "Backend Saturuma Google Apps Script Aktif, Aman & Terhubung!"
        };
        break;

      case "verifyUserLogin":
        result = verifyUserLogin(args[0] !== undefined ? args[0] : requestData.username, args[1] !== undefined ? args[1] : requestData.password);
        break;

      case "validateSession":
        result = validateSession(args[0] !== undefined ? args[0] : requestData.sessionToken);
        break;

      case "logoutUser":
        result = logoutUser(args[0] !== undefined ? args[0] : requestData.sessionToken);
        break;

      case "changeCurrentUserPassword":
      case "changeUserPassword":
        result = changeCurrentUserPassword(
          args[0] !== undefined ? args[0] : requestData.sessionToken,
          args[1] !== undefined ? args[1] : requestData.oldPassword,
          args[2] !== undefined ? args[2] : requestData.newPassword
        );
        break;

      case "registerUser":
        result = registerUser(args[0] !== undefined ? args[0] : (requestData.payload || requestData));
        break;

      case "getAppMetadata":
        result = getAppMetadata(args[0] !== undefined ? args[0] : requestData.customSpreadsheetId);
        break;

      case "getRecentEntries": {
        const catSheet = args[0] !== undefined ? args[0] : (requestData.categorySheetName || "all");
        const limit = args[1] !== undefined ? args[1] : (requestData.limit || 500);
        const customId = args[2] !== undefined ? args[2] : requestData.customSpreadsheetId;
        const auth = getAuthUser(sessionToken, reqUserId);
        const authUserId = auth ? auth.userId : (reqUserId || "");
        const isAdmin = auth ? auth.role === "admin" : false;
        result = getRecentEntries(catSheet, limit, customId, authUserId, isAdmin);
        break;
      }

      case "saveTransactionToSheet": {
        const sheetName = args[0] !== undefined ? args[0] : requestData.sheetName;
        const payload = args[1] !== undefined ? args[1] : requestData.payload;
        if (payload) {
          const auth = getAuthUser(sessionToken, reqUserId);
          if (auth && auth.userId) {
            payload.userId = auth.userId;
          }
        }
        result = saveTransactionToSheet(sheetName, payload);
        break;
      }

      case "updateTransactionInSheet": {
        const sheetName = args[0] !== undefined ? args[0] : requestData.sheetName;
        const payload = args[1] !== undefined ? args[1] : requestData.payload;
        if (payload) {
          const auth = getAuthUser(sessionToken, reqUserId);
          if (auth && auth.userId) {
            payload.userId = auth.userId;
          }
        }
        result = updateTransactionInSheet(sheetName, payload);
        break;
      }

      case "deleteTransactionFromSheet": {
        const sheetName = args[0] !== undefined ? args[0] : requestData.sheetName;
        const receiptId = args[1] !== undefined ? args[1] : requestData.receiptId;
        const customId = args[2] !== undefined ? args[2] : requestData.customSpreadsheetId;
        result = deleteTransactionFromSheet(sheetName, receiptId, customId, sessionToken, reqUserId);
        break;
      }

      case "extractReceiptWithAI":
        result = extractReceiptWithAI(args[0] !== undefined ? args[0] : requestData.payload);
        break;

      case "syncSheetStructure": {
        const customId = args[0] !== undefined ? args[0] : requestData.customSpreadsheetId;
        result = syncSheetStructure(customId);
        break;
      }

      case "saveMasterCategories":
        result = saveMasterCategories(args[0] !== undefined ? args[0] : requestData.categories);
        break;

      case "getMasterCategories":
        result = getMasterCategories();
        break;

      case "saveGeminiApiKey":
        result = saveGeminiApiKey(args[0] !== undefined ? args[0] : requestData.key);
        break;

      case "getGeminiApiKeyStatus":
        result = getGeminiApiKeyStatus();
        break;

      case "saveMonthlyBudget":
        result = saveMonthlyBudget(args[0] !== undefined ? args[0] : requestData.budget);
        break;

      case "getMonthlyBudget":
        result = getMonthlyBudget();
        break;

      case "resetAdminLogin":
        result = resetAdminLogin();
        break;

      default:
        result = { success: false, message: "Aksi backend '" + action + "' tidak dikenali." };
        break;
    }

    return ContentService.createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    Logger.log("Error doPost: " + err.toString());
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      message: "Server Error: " + err.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * HELPER: SET SHARING PERMISSIONS SAFELY (DATA PRIVACY ENFORCED)
 * Folder root dan sistem tidak dibuka untuk publik agar transaksi & struk keuangan tetap privat.
 */
function setSafeSharing(driveResource) {
  if (!driveResource) return;
  // File struk dan database disimpan aman di Google Drive akun pemilik tanpa membuka izin publik
}

/**
 * HELPER: FOLDER PENYIMPANAN TERISOLASI PER PENGGUNA (DATA PRIVACY)
 */
function getUserStorageFolder(userId, parentFolder) {
  if (!userId || !parentFolder) return parentFolder;
  const cleanUser = String(userId).replace(/[^a-zA-Z0-9_-]/g, "_");
  const folders = parentFolder.getFoldersByName(cleanUser);
  if (folders.hasNext()) {
    return folders.next();
  }
  return parentFolder.createFolder(cleanUser);
}

/**
 * 2. OTOMATISASI FOLDER GOOGLE DRIVE
 */
function getStorageFolders() {
  const root = DriveApp.getRootFolder();
  
  let parentFolder;
  const parentFolders = root.getFoldersByName(CONFIG.PARENT_FOLDER_NAME);
  if (parentFolders.hasNext()) {
    parentFolder = parentFolders.next();
  } else {
    parentFolder = root.createFolder(CONFIG.PARENT_FOLDER_NAME);
  }

  let itemFolder;
  const itemFolders = parentFolder.getFoldersByName(CONFIG.ITEM_PHOTOS_FOLDER);
  if (itemFolders.hasNext()) {
    itemFolder = itemFolders.next();
  } else {
    itemFolder = parentFolder.createFolder(CONFIG.ITEM_PHOTOS_FOLDER);
  }

  let receiptFolder;
  const receiptFolders = parentFolder.getFoldersByName(CONFIG.RECEIPTS_FOLDER);
  if (receiptFolders.hasNext()) {
    receiptFolder = receiptFolders.next();
  } else {
    receiptFolder = parentFolder.createFolder(CONFIG.RECEIPTS_FOLDER);
  }

  return { parent: parentFolder, items: itemFolder, receipts: receiptFolder };
}

/**
 * Helper: Ekstrak Spreadsheet ID dari link URL penuh atau string ID langsung
 */
function extractSpreadsheetId(urlOrId) {
  if (!urlOrId || typeof urlOrId !== "string") return "";
  const trimmed = urlOrId.trim();
  const match = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (match && match[1]) {
    return match[1];
  }
  if (trimmed.length > 20 && !trimmed.includes("/")) {
    return trimmed;
  }
  return trimmed;
}

/**
 * 3. OTOMATISASI SPREADSHEET & DYNAMIC SHEET ROUTING
 * Mendukung Dedicated Spreadsheet per User (BYOD) atau Master Spreadsheet
 */
function getSpreadsheetInstance(customId) {
  if (customId) {
    try {
      const cleanId = extractSpreadsheetId(customId);
      if (cleanId) {
        return SpreadsheetApp.openById(cleanId);
      }
    } catch (openCustomErr) {
      Logger.log("Peringatan: Gagal membuka spreadsheet khusus user (" + customId + "): " + openCustomErr.toString() + ". Menggunakan database utama.");
    }
  }

  let ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) {
    const props = PropertiesService.getScriptProperties();
    const savedId = props.getProperty("SPREADSHEET_ID");
    if (savedId) {
      try {
        ss = SpreadsheetApp.openById(savedId);
      } catch (openErr) {
        Logger.log("Gagal membuka spreadsheet tersimpan: " + openErr.toString());
      }
    }
    if (!ss) {
      ss = SpreadsheetApp.create("Saturuma - Super-App Keuangan & Manajemen Rumah Tangga");
      props.setProperty("SPREADSHEET_ID", ss.getId());
      Logger.log("Spreadsheet baru dibuat: " + ss.getUrl());
    }
  }
  return ss;
}

/**
 * Mendapatkan atau membuat sheet transaksi dengan header standar 14 kolom (termasuk Other / Biaya Lainnya)
 */
function getOrInitSheet(sheetName, headerColor, customId) {
  const targetSheetName = sheetName || "DB_Bayi";
  const ss = getSpreadsheetInstance(customId);
  let sheet = ss.getSheetByName(targetSheetName);

  if (!sheet) {
    if (ss.getSheets().length === 1 && ss.getSheets()[0].getLastRow() === 0) {
      sheet = ss.getSheets()[0];
      sheet.setName(targetSheetName);
    } else {
      sheet = ss.insertSheet(targetSheetName);
    }
  }

  // Pastikan kolom cukup untuk standar 14 kolom
  if (sheet.getMaxColumns() < CONFIG.STANDARD_COLUMNS.length) {
    sheet.insertColumnsAfter(sheet.getMaxColumns(), CONFIG.STANDARD_COLUMNS.length - sheet.getMaxColumns());
  }

  // Tulis header jika sheet masih kosong
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(CONFIG.STANDARD_COLUMNS);
    const headerRange = sheet.getRange(1, 1, 1, CONFIG.STANDARD_COLUMNS.length);
    headerRange.setFontWeight("bold")
      .setBackground(headerColor || "#10B981")
      .setFontColor("#ffffff")
      .setHorizontalAlignment("center");
    sheet.setFrozenRows(1);
    sheet.autoResizeColumns(1, CONFIG.STANDARD_COLUMNS.length);
  } else {
    // Auto-migrasi sheet: cek apakah kolom 'Other' sudah ada di header sheet
    const numCols = Math.max(sheet.getLastColumn(), 1);
    const headers = sheet.getRange(1, 1, 1, numCols).getValues()[0].map(h => String(h || "").trim().toLowerCase());
    const hasOther = headers.some(h => h === "other" || h === "otherfee" || h === "biayalainnya" || h === "lainnya" || h === "biaya lainnya");

    if (!hasOther && numCols >= 10) {
      // Sisipkan kolom "Other" setelah kolom Tax (atau sebelum ItemPhotoUrl)
      let insertIdx = 11; // Posisi kolom ke-11 standar
      const taxIdx = headers.indexOf("tax");
      const photoIdx = headers.findIndex(h => h.includes("itemphoto"));
      if (taxIdx !== -1) {
        insertIdx = taxIdx + 2; // 1-based, setelah Tax
      } else if (photoIdx !== -1) {
        insertIdx = photoIdx + 1; // 1-based, sebelum ItemPhotoUrl
      }

      sheet.insertColumnBefore(insertIdx);
      sheet.getRange(1, insertIdx).setValue("Other")
        .setFontWeight("bold")
        .setBackground(headerColor || "#10B981")
        .setFontColor("#ffffff")
        .setHorizontalAlignment("center");
    }

    // Pastikan header memenuhi standar 14 kolom
    if (sheet.getMaxColumns() < CONFIG.STANDARD_COLUMNS.length) {
      sheet.insertColumnsAfter(sheet.getMaxColumns(), CONFIG.STANDARD_COLUMNS.length - sheet.getMaxColumns());
    }
    sheet.getRange(1, 1, 1, CONFIG.STANDARD_COLUMNS.length).setValues([CONFIG.STANDARD_COLUMNS]);
    sheet.getRange(1, 1, 1, CONFIG.STANDARD_COLUMNS.length)
      .setFontWeight("bold")
      .setBackground(headerColor || "#10B981")
      .setFontColor("#ffffff")
      .setHorizontalAlignment("center");
  }

  return sheet;
}

/**
 * 4. SIMPAN BASE64 KE GOOGLE DRIVE
 */
function saveBase64File(base64String, fileNamePrefix, targetFolder) {
  if (!base64String || typeof base64String !== "string" || base64String.trim() === "") {
    return "";
  }
  if (base64String.indexOf("http://") === 0 || base64String.indexOf("https://") === 0) {
    return base64String;
  }

  try {
    let contentType = "image/jpeg";
    let extension = "jpg";
    let rawData = base64String;

    if (base64String.indexOf("data:") === 0) {
      const parts = base64String.split(",");
      const meta = parts[0];
      rawData = parts[1];

      const match = meta.match(/:(.*?);/);
      if (match && match[1]) {
        contentType = match[1];
        if (contentType === "application/pdf") extension = "pdf";
        else if (contentType === "image/png") extension = "png";
        else if (contentType === "image/webp") extension = "webp";
        else if (contentType === "image/jpeg") extension = "jpg";
      }
    }

    const decoded = Utilities.base64Decode(rawData);
    const timestampStr = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || "GMT+7", "yyyyMMdd_HHmmss_SSS");
    const fileName = fileNamePrefix + "_" + timestampStr + "." + extension;
    
    const blob = Utilities.newBlob(decoded, contentType, fileName);
    const file = targetFolder.createFile(blob);
    
    setSafeSharing(file);
    const fileId = file.getId();
    if (contentType === "application/pdf") {
      return file.getUrl();
    }
    // Mengembalikan URL thumbnail langsung agar foto bisa tampil mulus di <img> tag frontend
    return "https://drive.google.com/thumbnail?id=" + fileId + "&sz=w1200";
  } catch (err) {
    Logger.log("Error saveBase64File: " + err.toString());
    return "";
  }
}

/**
 * 5. MANAJEMEN MASTER KATEGORI (CRUD)
 */
function getMasterCategories() {
  try {
    const props = PropertiesService.getScriptProperties();
    const raw = props.getProperty("MASTER_CATEGORIES");
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }

    // Jika belum ada di Properties, coba cek di Sheet "Config_Master"
    const ss = getSpreadsheetInstance();
    const configSheet = ss.getSheetByName(CONFIG.CONFIG_SHEET_NAME);
    if (configSheet && configSheet.getLastRow() > 1) {
      const rows = configSheet.getRange(2, 1, configSheet.getLastRow() - 1, 6).getValues();
      const list = rows.map(r => ({
        id: String(r[0]),
        name: String(r[1]),
        sheetName: String(r[2]),
        color: String(r[3]),
        icon: String(r[4]),
        subCategories: r[5] ? String(r[5]).split(",").map(s => s.trim()) : []
      })).filter(c => c.id && c.sheetName);

      if (list.length > 0) {
        props.setProperty("MASTER_CATEGORIES", JSON.stringify(list));
        return list;
      }
    }
  } catch (e) {
    Logger.log("Error getMasterCategories: " + e.toString());
  }

  // Simpan konfigurasi default jika belum ada
  saveMasterCategories(CONFIG.DEFAULT_CATEGORIES);
  return CONFIG.DEFAULT_CATEGORIES;
}

function saveMasterCategories(categories) {
  try {
    if (!categories || !Array.isArray(categories) || categories.length === 0) {
      return { success: false, message: "Daftar kategori master tidak valid." };
    }

    const cleanList = categories.map((c, idx) => ({
      id: c.id || ("cat_" + (idx + 1)),
      name: String(c.name || "Kategori " + (idx + 1)).trim(),
      sheetName: String(c.sheetName || "DB_Kategori" + (idx + 1)).trim().replace(/\s+/g, "_"),
      color: c.color || "#10B981",
      icon: c.icon || "fa-folder",
      subCategories: Array.isArray(c.subCategories) ? c.subCategories.filter(s => s && s.trim().length > 0) : []
    }));

    // Simpan ke PropertiesService
    PropertiesService.getScriptProperties().setProperty("MASTER_CATEGORIES", JSON.stringify(cleanList));

    // Sinkronkan ke Sheet Config_Master untuk transparansi pengguna
    try {
      const ss = getSpreadsheetInstance();
      let configSheet = ss.getSheetByName(CONFIG.CONFIG_SHEET_NAME);
      if (!configSheet) {
        configSheet = ss.insertSheet(CONFIG.CONFIG_SHEET_NAME);
      }
      configSheet.clear();
      configSheet.appendRow(["ID", "Nama Kategori", "Sheet DB", "Warna Hex", "Icon FA", "Sub Kategori"]);
      configSheet.getRange(1, 1, 1, 6).setFontWeight("bold").setBackground("#374151").setFontColor("#ffffff");
      
      const rows = cleanList.map(c => [
        c.id,
        c.name,
        c.sheetName,
        c.color,
        c.icon,
        (c.subCategories || []).join(", ")
      ]);
      if (rows.length > 0) {
        configSheet.getRange(2, 1, rows.length, 6).setValues(rows);
      }
      configSheet.autoResizeColumns(1, 6);
    } catch (sheetErr) {
      Logger.log("Sinkronisasi sheet config diabaikan: " + sheetErr.toString());
    }

    return { success: true, message: "Master Kategori berhasil disimpan!", categories: cleanList };
  } catch (err) {
    Logger.log("Error saveMasterCategories: " + err.toString());
    return { success: false, message: err.message };
  }
}

/**
 * 6. SIMPAN TRANSAKSI KE SHEET DINAMIS (DYNAMIC SHEET ROUTING & DATA PRIVACY)
 * saveTransactionToSheet(categorySheetName, data)
 */
function saveTransactionToSheet(categorySheetName, data) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
  } catch (lockErr) {
    return { success: false, message: "Server sedang sibuk memproses antrean transaksi. Silakan coba sesaat lagi." };
  }

  try {
    if (!data) return { success: false, message: "Data transaksi tidak valid." };

    const targetSheet = categorySheetName || data.categorySheetName || "DB_Dapur";
    const masterCats = getMasterCategories();
    const catConfig = masterCats.find(c => c.sheetName === targetSheet) || { color: "#8B5CF6", name: "Multi-Modul" };

    let items = [];
    if (data.items && Array.isArray(data.items) && data.items.length > 0) {
      items = data.items;
    } else if (data.itemName) {
      items = [{
        itemName: data.itemName,
        subCategory: data.subCategory || data.category || "Lainnya/Other",
        qty: Number(data.qty) || 1,
        cost: Number(data.cost) || 0
      }];
    }

    if (items.length === 0) {
      const merchant = String(data.merchant || catConfig.name || "Belanja").trim();
      items = [{
        itemName: merchant,
        subCategory: "Lainnya/Other",
        qty: 1,
        cost: Number(data.subtotal) || Number(data.cost) || 0
      }];
    }

    const folders = getStorageFolders();
    const userId = String((data && data.userId) || "").trim() || "USR_DEFAULT";
    const userReceiptFolder = getUserStorageFolder(userId, folders.receipts);
    const userItemFolder = getUserStorageFolder(userId, folders.items);

    // Simpan foto barang bawaan jika ada
    let defaultItemPhotoUrl = "";
    if (data.itemPhotoBase64) {
      defaultItemPhotoUrl = saveBase64File(data.itemPhotoBase64, "item", userItemFolder);
    }

    // Simpan foto/PDF struk jika ada
    let receiptPhotoUrl = "";
    if (data.receiptPhotoBase64) {
      receiptPhotoUrl = saveBase64File(data.receiptPhotoBase64, "struk", userReceiptFolder);
    }

    const sheetCache = {};
    function getSheet(sheetName) {
      if (!sheetCache[sheetName]) {
        const itemCatConfig = masterCats.find(c => c.sheetName === sheetName) || { color: "#10B981" };
        sheetCache[sheetName] = getOrInitSheet(sheetName, itemCatConfig.color, data ? data.customSpreadsheetId : null);
      }
      return sheetCache[sheetName];
    }

    const timestamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || "GMT+7", "yyyy-MM-dd HH:mm:ss");
    const receiptDate = data.date || Utilities.formatDate(new Date(), Session.getScriptTimeZone() || "GMT+7", "yyyy-MM-dd");
    const merchant = String(data.merchant || catConfig.name || "Belanja Rumah Tangga").trim();
    const receiptId = data.receiptId || ("REC-" + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || "GMT+7", "yyyyMMdd_HHmmss"));
    const discount = Number(data.discount) || 0;
    const tax = Number(data.tax) || 0;
    const other = Number(data.other) || 0;

    let subtotal = 0;
    for (let i = 0; i < items.length; i++) {
      subtotal += ((Number(items[i].cost) || 0) * (Number(items[i].qty) || 1));
    }

    let remainingDiscount = discount;
    let remainingTax = tax;
    let remainingOther = other;

    const createdRows = [];
    const rowsBySheet = {};

    // Catat setiap barang ke sheet target (Format 14 kolom dengan Other & UserID untuk privasi data)
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      const itemName = String(it.itemName || "Item " + (i + 1)).trim();
      const subCategory = it.subCategory || it.category || "Lainnya";
      const qty = Number(it.qty) || 1;
      const cost = Number(it.cost) || 0;
      const lineCost = cost * qty;

      let itemDiscount = 0;
      let itemTax = 0;
      let itemOther = 0;

      if (it.discount !== undefined && it.discount !== null && it.tax !== undefined && it.other !== undefined) {
        itemDiscount = Number(it.discount) || 0;
        itemTax = Number(it.tax) || 0;
        itemOther = Number(it.other) || 0;
      } else {
        if (i === items.length - 1) {
          itemDiscount = remainingDiscount;
          itemTax = remainingTax;
          itemOther = remainingOther;
        } else {
          const ratio = subtotal > 0 ? (lineCost / subtotal) : (1 / items.length);
          itemDiscount = Math.round(discount * ratio);
          itemTax = Math.round(tax * ratio);
          itemOther = Math.round(other * ratio);
          remainingDiscount -= itemDiscount;
          remainingTax -= itemTax;
          remainingOther -= itemOther;
        }
      }

      let thisItemPhotoUrl = "";
      if (it.itemPhotoBase64) {
        const cleanName = itemName.replace(/[^a-zA-Z0-9]/g, "_").substring(0, 15);
        thisItemPhotoUrl = saveBase64File(it.itemPhotoBase64, "item_" + cleanName, userItemFolder);
      } else if (it.itemPhotoUrl) {
        thisItemPhotoUrl = it.itemPhotoUrl;
      } else if (defaultItemPhotoUrl) {
        thisItemPhotoUrl = defaultItemPhotoUrl;
      }

      // Format standard 14 kolom:
      // [Timestamp, Date, ReceiptID, Merchant, ItemName, SubCategory, Qty, Cost, Discount, Tax, Other, ItemPhotoUrl, ReceiptPhotoUrl, UserID]
      const rowData = [
        timestamp,
        receiptDate,
        receiptId,
        merchant,
        itemName,
        subCategory,
        qty,
        cost,
        itemDiscount, // Alokasi diskon struk proporsional
        itemTax,      // Alokasi pajak struk proporsional
        itemOther,    // Alokasi biaya lainnya/other proporsional
        thisItemPhotoUrl,
        receiptPhotoUrl,
        userId
      ];

      const itemSheetName = it.categorySheetName || it.sheetName || (targetSheet !== "DB_Multi" && targetSheet !== "all" ? targetSheet : (masterCats[0] ? masterCats[0].sheetName : "DB_Dapur"));
      if (!rowsBySheet[itemSheetName]) rowsBySheet[itemSheetName] = [];
      rowsBySheet[itemSheetName].push(rowData);

      createdRows.push({
        timestamp: timestamp,
        date: receiptDate,
        receiptId: receiptId,
        merchant: merchant,
        itemName: itemName,
        subCategory: subCategory,
        qty: qty,
        cost: cost,
        discount: discount,
        tax: tax,
        other: other,
        itemPhotoUrl: thisItemPhotoUrl,
        receiptPhotoUrl: receiptPhotoUrl,
        sheetName: itemSheetName,
        userId: userId
      });
    }

    // Eksekusi Batch Writing per sheet sekaligus (Hanya 1x roundtrip per sheet)
    Object.keys(rowsBySheet).forEach(sheetName => {
      const sheet = getSheet(sheetName);
      const batchRows = rowsBySheet[sheetName];
      if (batchRows.length > 0) {
        const startRow = sheet.getLastRow() + 1;
        sheet.getRange(startRow, 1, batchRows.length, 14).setValues(batchRows);
        const numFormats = batchRows.map(() => ["#,##0", "#,##0", "#,##0", "#,##0;(#,##0);0"]);
        sheet.getRange(startRow, 8, batchRows.length, 4).setNumberFormats(numFormats);
      }
    });

    return {
      success: true,
      message: `Berhasil mencatat ${items.length} transaksi ke sheet!`,
      receiptId: receiptId,
      sheetName: targetSheet,
      data: createdRows
    };
  } catch (err) {
    Logger.log("Error saveTransactionToSheet: " + err.toString());
    return {
      success: false,
      message: "Gagal menyimpan data ke sheet: " + err.message
    };
  } finally {
    lock.releaseLock();
  }
}

/**
 * Alias processForm untuk kompatibilitas mundur
 */
function processForm(data) {
  const targetSheet = data.categorySheetName || (data.masterCategory && data.masterCategory.sheetName) || "DB_Dapur";
  return saveTransactionToSheet(targetSheet, data);
}

/**
 * 7. PERBARUI TRANSAKSI DI SHEET TERPILIH (UPDATE & OWNERSHIP CHECK)
 */
function updateTransactionInSheet(categorySheetName, data) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
  } catch (lockErr) {
    return { success: false, message: "Server sedang sibuk memproses antrean transaksi. Silakan coba sesaat lagi." };
  }

  try {
    if (!data || !data.receiptId) {
      return { success: false, message: "ID Struk tidak valid untuk diperbarui." };
    }

    const targetSheet = categorySheetName || data.categorySheetName || "DB_Dapur";
    const masterCats = getMasterCategories();
    const catConfig = masterCats.find(c => c.sheetName === targetSheet) || { color: "#10B981" };

    let items = [];
    if (data.items && Array.isArray(data.items) && data.items.length > 0) {
      items = data.items;
    } else if (data.itemName) {
      items = [{
        itemName: data.itemName,
        subCategory: data.subCategory || data.category || "Lainnya/Other",
        qty: Number(data.qty) || 1,
        cost: Number(data.cost) || 0
      }];
    }

    if (items.length === 0) {
      const merchant = String(data.merchant || catConfig.name || "Belanja").trim();
      items = [{
        itemName: merchant,
        subCategory: "Lainnya/Other",
        qty: 1,
        cost: Number(data.subtotal) || Number(data.cost) || 0
      }];
    }

    const folders = getStorageFolders();
    const userId = String((data && data.userId) || "").trim() || "USR_DEFAULT";
    const userReceiptFolder = getUserStorageFolder(userId, folders.receipts);
    const userItemFolder = getUserStorageFolder(userId, folders.items);

    let receiptPhotoUrl = String(data.existingReceiptPhotoUrl || "");
    if (data.receiptPhotoBase64) {
      receiptPhotoUrl = saveBase64File(data.receiptPhotoBase64, "struk", userReceiptFolder);
    }

    const currentTimestamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || "GMT+7", "yyyy-MM-dd HH:mm:ss");
    const receiptDate = data.date || Utilities.formatDate(new Date(), Session.getScriptTimeZone() || "GMT+7", "yyyy-MM-dd");
    const merchant = String(data.merchant || "Belanja Rumah Tangga").trim();
    const targetReceiptId = String(data.receiptId).trim();
    const discount = Number(data.discount) || 0;
    const tax = Number(data.tax) || 0;
    const other = Number(data.other) || 0;

    let originalTimestamp = currentTimestamp;
    let originalUserId = userId;

    const isMulti = data.isMultiModule || targetSheet === "DB_Multi" || (data.items && data.items.some(it => it.categorySheetName && it.categorySheetName !== targetSheet));
    const ss = getSpreadsheetInstance(data ? data.customSpreadsheetId : null);

    const sheetCache = {};
    function getSheet(sheetName) {
      if (!sheetCache[sheetName]) {
        const itemCatConfig = masterCats.find(c => c.sheetName === sheetName) || { color: "#10B981" };
        sheetCache[sheetName] = getOrInitSheet(sheetName, itemCatConfig.color, data ? data.customSpreadsheetId : null);
      }
      return sheetCache[sheetName];
    }

    if (isMulti) {
      // Hapus baris transaksi lama di seluruh tab kategori
      const allSheets = ss.getSheets();
      allSheets.forEach(sh => {
        const lr = sh.getLastRow();
        if (lr > 1) {
          const nc = sh.getLastColumn();
          const dRange = sh.getRange(2, 1, lr - 1, nc).getValues();
          for (let i = dRange.length - 1; i >= 0; i--) {
            const row = dRange[i];
            if (String(row[2] || "") === targetReceiptId) {
              if (row[0]) originalTimestamp = row[0];
              const ownerCol = nc >= 14 ? 13 : (nc >= 13 ? 12 : -1);
              if (ownerCol !== -1 && row[ownerCol]) originalUserId = row[ownerCol];
              const photoCol = nc >= 14 ? 12 : (nc >= 13 ? 11 : 9);
              if (!receiptPhotoUrl && row[photoCol]) receiptPhotoUrl = String(row[photoCol]);
              sh.deleteRow(i + 2);
            }
          }
        }
      });

      // Tulis ulang baris item baru ke sheet kategori masing-masing
      let subtotal = 0;
      for (let i = 0; i < items.length; i++) {
        subtotal += ((Number(items[i].cost) || 0) * (Number(items[i].qty) || 1));
      }
      let remainingDiscount = discount;
      let remainingTax = tax;
      let remainingOther = other;

      for (let i = 0; i < items.length; i++) {
        const it = items[i];
        const itemName = String(it.itemName || "Item " + (i + 1)).trim();
        const subCategory = it.subCategory || it.category || "Lainnya";
        const qty = Number(it.qty) || 1;
        const cost = Number(it.cost) || 0;
        const lineCost = cost * qty;

        let itemDiscount = 0;
        let itemTax = 0;
        let itemOther = 0;

        if (it.discount !== undefined && it.discount !== null && it.tax !== undefined && it.other !== undefined) {
          itemDiscount = Number(it.discount) || 0;
          itemTax = Number(it.tax) || 0;
          itemOther = Number(it.other) || 0;
        } else {
          if (i === items.length - 1) {
            itemDiscount = remainingDiscount;
            itemTax = remainingTax;
            itemOther = remainingOther;
          } else {
            const ratio = subtotal > 0 ? (lineCost / subtotal) : (1 / items.length);
            itemDiscount = Math.round(discount * ratio);
            itemTax = Math.round(tax * ratio);
            itemOther = Math.round(other * ratio);
            remainingDiscount -= itemDiscount;
            remainingTax -= itemTax;
            remainingOther -= itemOther;
          }
        }

        let thisItemPhotoUrl = it.itemPhotoUrl || "";
        if (it.itemPhotoBase64) {
          const cleanName = itemName.replace(/[^a-zA-Z0-9]/g, "_").substring(0, 15);
          thisItemPhotoUrl = saveBase64File(it.itemPhotoBase64, "item_" + cleanName, userItemFolder);
        }

        const itemSheetName = it.categorySheetName || it.sheetName || (masterCats[0] ? masterCats[0].sheetName : "DB_Dapur");
        const sh = getSheet(itemSheetName);

        sh.appendRow([
          originalTimestamp,
          receiptDate,
          targetReceiptId,
          merchant,
          itemName,
          subCategory,
          qty,
          cost,
          itemDiscount,
          itemTax,
          itemOther,
          thisItemPhotoUrl,
          receiptPhotoUrl,
          originalUserId
        ]);
        const curLast = sh.getLastRow();
        sh.getRange(curLast, 8, 1, 4).setNumberFormat("#,##0");
      }

      return {
        success: true,
        message: `Berhasil memperbarui struk ${targetReceiptId} (Multi-Modul)!`,
        receiptId: targetReceiptId
      };
    }

    const sheet = getOrInitSheet(targetSheet, catConfig.color, data ? data.customSpreadsheetId : null);
    const lastRow = sheet.getLastRow();
    const numCols = sheet.getLastColumn();

    let insertRowIndex = -1;

    if (lastRow > 1) {
      const dataRange = sheet.getRange(2, 1, lastRow - 1, numCols).getValues();
      for (let i = dataRange.length - 1; i >= 0; i--) {
        const row = dataRange[i];
        const rId = String(row[2] || "");
        if (rId === targetReceiptId) {
          const rowOwner = numCols >= 14 ? String(row[13] || "").trim() : (numCols >= 13 ? String(row[12] || "").trim() : "");
          // Privacy check: Jika database bersama dan baris memiliki pemilik lain
          if (!data.customSpreadsheetId && rowOwner && userId && rowOwner !== userId && userId !== "USR_ADMIN") {
            return {
              success: false,
              message: "Akses ditolak: Anda tidak memiliki izin untuk mengubah transaksi milik akun lain."
            };
          }
          insertRowIndex = i + 2;
          if (row[0]) originalTimestamp = row[0];
          if (rowOwner) originalUserId = rowOwner;
          const photoCol = numCols >= 14 ? 12 : (numCols >= 13 ? 11 : 9);
          if (!receiptPhotoUrl && row[photoCol]) receiptPhotoUrl = String(row[photoCol]);
          sheet.deleteRow(i + 2);
        }
      }
    }

    if (insertRowIndex === -1 || insertRowIndex > sheet.getLastRow() + 1) {
      insertRowIndex = sheet.getLastRow() + 1;
    }

    let subtotalSingle = 0;
    for (let i = 0; i < items.length; i++) {
      subtotalSingle += ((Number(items[i].cost) || 0) * (Number(items[i].qty) || 1));
    }
    let remDiscountSingle = discount;
    let remTaxSingle = tax;
    let remOtherSingle = other;

    const newRows = [];
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      const itemName = String(it.itemName || "Item " + (i + 1)).trim();
      const subCategory = it.subCategory || it.category || "Lainnya";
      const qty = Number(it.qty) || 1;
      const cost = Number(it.cost) || 0;
      const lineCost = cost * qty;

      let itemDiscount = 0;
      let itemTax = 0;
      let itemOther = 0;

      if (it.discount !== undefined && it.discount !== null && it.tax !== undefined && it.other !== undefined) {
        itemDiscount = Number(it.discount) || 0;
        itemTax = Number(it.tax) || 0;
        itemOther = Number(it.other) || 0;
      } else {
        if (i === items.length - 1) {
          itemDiscount = remDiscountSingle;
          itemTax = remTaxSingle;
          itemOther = remOtherSingle;
        } else {
          const ratio = subtotalSingle > 0 ? (lineCost / subtotalSingle) : (1 / items.length);
          itemDiscount = Math.round(discount * ratio);
          itemTax = Math.round(tax * ratio);
          itemOther = Math.round(other * ratio);
          remDiscountSingle -= itemDiscount;
          remTaxSingle -= itemTax;
          remOtherSingle -= itemOther;
        }
      }

      let thisItemPhotoUrl = it.itemPhotoUrl || "";
      if (it.itemPhotoBase64) {
        const cleanName = itemName.replace(/[^a-zA-Z0-9]/g, "_").substring(0, 15);
        thisItemPhotoUrl = saveBase64File(it.itemPhotoBase64, "item_" + cleanName, userItemFolder);
      }

      newRows.push([
        originalTimestamp,
        receiptDate,
        targetReceiptId,
        merchant,
        itemName,
        subCategory,
        qty,
        cost,
        itemDiscount,
        itemTax,
        itemOther,
        thisItemPhotoUrl,
        receiptPhotoUrl,
        originalUserId
      ]);
    }

    if (insertRowIndex <= sheet.getLastRow()) {
      sheet.insertRowsBefore(insertRowIndex, newRows.length);
      const range = sheet.getRange(insertRowIndex, 1, newRows.length, CONFIG.STANDARD_COLUMNS.length);
      range.setValues(newRows);
      sheet.getRange(insertRowIndex, 8, newRows.length, 4).setNumberFormat("#,##0");
    } else {
      for (let r = 0; r < newRows.length; r++) {
        sheet.appendRow(newRows[r]);
        const curLast = sheet.getLastRow();
        sheet.getRange(curLast, 8, 1, 4).setNumberFormat("#,##0");
      }
    }

    return {
      success: true,
      message: `Berhasil memperbarui struk ${targetReceiptId} di sheet [${targetSheet}]!`,
      receiptId: targetReceiptId
    };
  } catch (err) {
    Logger.log("Error updateTransactionInSheet: " + err.toString());
    return { success: false, message: "Gagal memperbarui transaksi: " + err.message };
  } finally {
    lock.releaseLock();
  }
}

/**
 * 8. HAPUS STRUK DARI SHEET (DELETE & OWNERSHIP CHECK)
 */
function deleteTransactionFromSheet(categorySheetName, receiptId, customSpreadsheetId, sessionToken, requestingUserId) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
  } catch (lockErr) {
    return { success: false, message: "Server sedang sibuk memproses antrean transaksi. Silakan coba sesaat lagi." };
  }

  try {
    if (!receiptId) return { success: false, message: "ID Struk tidak valid." };

    const auth = getAuthUser(sessionToken, requestingUserId);
    const authUserId = auth ? auth.userId : (requestingUserId || "");
    const isAdmin = auth ? auth.role === "admin" : false;
    const isShared = !customSpreadsheetId;

    const ss = getSpreadsheetInstance(customSpreadsheetId);
    const sheetsToSearch = [];

    if (categorySheetName) {
      const sh = ss.getSheetByName(categorySheetName);
      if (sh) sheetsToSearch.push(sh);
    } else {
      // Cari di seluruh sheet kategori yang ada
      const masterCats = getMasterCategories();
      masterCats.forEach(c => {
        const sh = ss.getSheetByName(c.sheetName);
        if (sh) sheetsToSearch.push(sh);
      });
    }

    let totalDeleted = 0;
    let unauthorizedCount = 0;

    sheetsToSearch.forEach(sheet => {
      const lastRow = sheet.getLastRow();
      if (lastRow > 1) {
        const numCols = sheet.getLastColumn();
        const dataRange = sheet.getRange(2, 1, lastRow - 1, numCols).getValues();

        for (let i = dataRange.length - 1; i >= 0; i--) {
          const row = dataRange[i];
          const rId = String(row[2] || "");
          if (rId === receiptId) {
            // Dalam arsitektur 1 database terpadu (kolaboratif), seluruh anggota keluarga/tim diizinkan mengelola struk bersama
            sheet.deleteRow(i + 2);
            totalDeleted++;
          }
        }
      }
    });

    if (unauthorizedCount > 0 && totalDeleted === 0) {
      return {
        success: false,
        message: "Akses ditolak: Anda tidak memiliki izin menghapus transaksi milik akun lain."
      };
    }

    return {
      success: true,
      message: `Berhasil menghapus ${totalDeleted} baris transaksi dengan ID: ${receiptId}.`,
      rowsDeleted: totalDeleted
    };
  } catch (err) {
    Logger.log("Error deleteTransactionFromSheet: " + err.toString());
    return { success: false, message: "Gagal menghapus transaksi: " + err.message };
  } finally {
    lock.releaseLock();
  }
}

/**
 * Alias deleteReceipt untuk kompatibilitas mundur
 */
function deleteReceipt(receiptId, categorySheetName) {
  return deleteTransactionFromSheet(categorySheetName, receiptId);
}

/**
 * 9. AMBIL DATA ENTRI TERBARU, KPI & STATISTIK (DILENGKAPI FILTER PRIVASI USER)
 */
function getRecentEntries(categorySheetName, limit, customSpreadsheetId, authUserId, isAdmin) {
  try {
    const maxEntries = limit || 500;
    const ss = getSpreadsheetInstance(customSpreadsheetId);
    const isSharedDatabase = !customSpreadsheetId;
    const masterCats = getMasterCategories();
    const monthlyBudget = getMonthlyBudget();
    const currentYearMonth = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || "GMT+7", "yyyy-MM");
    const todayStr = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || "GMT+7", "yyyy-MM-dd");

    // Tentukan sheet mana saja yang akan dibaca
    const targetSheets = [];
    if (categorySheetName && categorySheetName !== "all" && categorySheetName !== "ALL") {
      const found = masterCats.find(c => c.sheetName === categorySheetName || c.id === categorySheetName);
      if (found) {
        targetSheets.push(found);
      } else {
        targetSheets.push({ id: categorySheetName, name: categorySheetName, sheetName: categorySheetName, color: "#10B981" });
      }
    } else {
      masterCats.forEach(c => targetSheets.push(c));
    }

    let totalSpent = 0;
    let thisMonthSpent = 0;
    let todaySpent = 0;
    const categoryBreakdown = {};
    const subCategoryBreakdown = {};
    const monthlyBreakdown = {};
    const allEntries = [];

    // Peta Nama Tampilan Pengguna (UserID/Username -> Nama Lengkap Pencatat)
    const userDisplayMap = getUserDisplayNameMap();

    targetSheets.forEach(cat => {
      const sheet = ss.getSheetByName(cat.sheetName);
      if (!sheet) return;

      const lastRow = sheet.getLastRow();
      if (lastRow <= 1) return;

      const numRows = lastRow - 1;
      const numCols = sheet.getLastColumn();
      const dataRange = sheet.getRange(2, 1, numRows, numCols).getValues();

      for (let i = 0; i < dataRange.length; i++) {
        const row = dataRange[i];

        // ARSITEKTUR 1 DATABASE TERPADU (KOLABORATIF SATU RUMAH):
        // Seluruh transaksi dari semua user dimuat bersama agar estafet catatan dan rekap keuangan terintegrasi.
        const rowUserId = numCols >= 14 ? String(row[13] || "").trim() : (numCols >= 13 ? String(row[12] || "").trim() : "");
        const createdByName = (rowUserId && userDisplayMap[rowUserId]) ? userDisplayMap[rowUserId] : (rowUserId || "Anggota Keluarga");

        let timestamp = row[0];
        let date = row[1];
        let receiptId = "";
        let merchant = "";
        let itemName = "";
        let subCategory = "Lainnya";
        let qty = 1;
        let cost = 0;
        let discount = 0;
        let tax = 0;
        let other = 0;
        let itemPhotoUrl = "";
        let receiptPhotoUrl = "";

        if (numCols >= 14) {
          // Standard 14 Kolom (Dengan Kolom Other / Biaya Lainnya & Privacy)
          receiptId = String(row[2] || "");
          merchant = String(row[3] || "");
          itemName = String(row[4] || "");
          subCategory = String(row[5] || "Lainnya");
          qty = Number(row[6]) || 1;
          cost = Number(row[7]) || 0;
          discount = Number(row[8]) || 0;
          tax = Number(row[9]) || 0;
          other = Number(row[10]) || 0;
          itemPhotoUrl = String(row[11] || "");
          receiptPhotoUrl = String(row[12] || "");
        } else if (numCols >= 13) {
          // Standard 13 Kolom (Legacy tanpa Other)
          receiptId = String(row[2] || "");
          merchant = String(row[3] || "");
          itemName = String(row[4] || "");
          subCategory = String(row[5] || "Lainnya");
          qty = Number(row[6]) || 1;
          cost = Number(row[7]) || 0;
          discount = Number(row[8]) || 0;
          tax = Number(row[9]) || 0;
          other = 0;
          itemPhotoUrl = String(row[10] || "");
          receiptPhotoUrl = String(row[11] || "");
        } else if (numCols >= 12) {
          // Standard 12 Kolom (Legacy)
          receiptId = String(row[2] || "");
          merchant = String(row[3] || "");
          itemName = String(row[4] || "");
          subCategory = String(row[5] || "Lainnya");
          qty = Number(row[6]) || 1;
          cost = Number(row[7]) || 0;
          discount = Number(row[8]) || 0;
          tax = Number(row[9]) || 0;
          other = 0;
          itemPhotoUrl = String(row[10] || "");
          receiptPhotoUrl = String(row[11] || "");
        } else if (numCols >= 9) {
          // Format 10 kolom BabyNest sebelumnya
          receiptId = String(row[2] || "");
          merchant = String(row[3] || "");
          itemName = String(row[4] || "");
          subCategory = String(row[5] || "Lainnya");
          qty = Number(row[6]) || 1;
          cost = Number(row[7]) || 0;
          other = 0;
          itemPhotoUrl = String(row[8] || "");
          receiptPhotoUrl = String(row[9] || "");
        } else {
          // Legacy format
          itemName = String(row[2] || "");
          subCategory = String(row[3] || "Lainnya");
          merchant = String(row[4] || "");
          cost = Number(row[5]) || 0;
          other = 0;
          itemPhotoUrl = String(row[6] || "");
          receiptPhotoUrl = String(row[7] || "");
          receiptId = "REC-LEGACY-" + (i + 1);
        }

        const lineCost = (Number(cost) || 0) * (Number(qty) || 1);
        const netCost = Math.max(0, lineCost - discount + tax + other);

        totalSpent += netCost;
        const catName = cat.name || cat.sheetName;
        categoryBreakdown[catName] = (categoryBreakdown[catName] || 0) + netCost;
        subCategoryBreakdown[subCategory] = (subCategoryBreakdown[subCategory] || 0) + netCost;

        let formattedDate = "";
        if (date instanceof Date) {
          formattedDate = Utilities.formatDate(date, Session.getScriptTimeZone() || "GMT+7", "yyyy-MM-dd");
        } else if (date) {
          formattedDate = String(date).split("T")[0];
        } else {
          formattedDate = todayStr;
        }

        let formattedTimestamp = "";
        if (timestamp instanceof Date) {
          formattedTimestamp = Utilities.formatDate(timestamp, Session.getScriptTimeZone() || "GMT+7", "yyyy-MM-dd HH:mm:ss");
        } else {
          formattedTimestamp = String(timestamp || "");
        }

        const ym = formattedDate.substring(0, 7) || currentYearMonth;
        monthlyBreakdown[ym] = (monthlyBreakdown[ym] || 0) + netCost;

        if (ym === currentYearMonth) {
          thisMonthSpent += netCost;
        }
        if (formattedDate === todayStr) {
          todaySpent += netCost;
        }

        allEntries.push({
          rowIndex: i + 2,
          masterCategoryId: cat.id,
          masterCategoryName: cat.name,
          masterSheetName: cat.sheetName,
          categoryColor: cat.color,
          timestamp: formattedTimestamp,
          date: formattedDate,
          receiptId: receiptId,
          merchant: merchant,
          itemName: itemName,
          subCategory: subCategory,
          qty: qty,
          cost: cost,
          discount: discount,
          tax: tax,
          other: other,
          itemPhotoUrl: itemPhotoUrl,
          receiptPhotoUrl: receiptPhotoUrl,
          userId: rowUserId,
          createdByName: createdByName
        });
      }
    });

    // Kelompokkan per ID Struk
    const receiptMap = {};
    for (let i = 0; i < allEntries.length; i++) {
      const it = allEntries[i];
      const rId = it.receiptId || ("REC-SINGLE-" + i);

      if (!receiptMap[rId]) {
        receiptMap[rId] = {
          receiptId: rId,
          masterCategoryId: it.masterCategoryId,
          masterCategoryName: it.masterCategoryName,
          masterSheetName: it.masterSheetName,
          categoryColor: it.categoryColor,
          date: it.date,
          merchant: it.merchant,
          timestamp: it.timestamp,
          itemPhotoUrl: it.itemPhotoUrl,
          receiptPhotoUrl: it.receiptPhotoUrl,
          userId: it.userId,
          createdByName: it.createdByName,
          totalCost: 0,
          subtotal: 0,
          totalDiscount: 0,
          totalTax: 0,
          totalOther: 0,
          totalAmount: 0,
          items: []
        };
      }

      receiptMap[rId].totalCost += it.cost;
      receiptMap[rId].subtotal = receiptMap[rId].totalCost;
      receiptMap[rId].totalDiscount += it.discount;
      receiptMap[rId].totalTax += it.tax;
      receiptMap[rId].totalOther += it.other;
      receiptMap[rId].totalAmount = Math.max(0, receiptMap[rId].totalCost - receiptMap[rId].totalDiscount + receiptMap[rId].totalTax + receiptMap[rId].totalOther);
      receiptMap[rId].items.push({
        itemName: it.itemName,
        subCategory: it.subCategory,
        qty: it.qty,
        cost: it.cost,
        itemPhotoUrl: it.itemPhotoUrl
      });

      if (it.itemPhotoUrl && !receiptMap[rId].itemPhotoUrl) receiptMap[rId].itemPhotoUrl = it.itemPhotoUrl;
      if (it.receiptPhotoUrl && !receiptMap[rId].receiptPhotoUrl) receiptMap[rId].receiptPhotoUrl = it.receiptPhotoUrl;
    }

    const receiptsList = Object.keys(receiptMap).map(k => receiptMap[k]).sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    const recentFlatEntries = allEntries.sort((a, b) => (b.date || "").localeCompare(a.date || "")).slice(0, maxEntries);

    // Hitung rata-rata harian bulan ini
    const todayDate = new Date();
    const currentDayOfMonth = todayDate.getDate() || 1;
    const dailyAverage = Math.round(thisMonthSpent / currentDayOfMonth);

    return {
      success: true,
      stats: {
        totalSpent: totalSpent,
        totalItems: allEntries.length,
        totalReceipts: receiptsList.length,
        thisMonthSpent: thisMonthSpent,
        todaySpent: todaySpent,
        dailyAverage: dailyAverage,
        currentYearMonth: currentYearMonth,
        categoryBreakdown: categoryBreakdown,
        subCategoryBreakdown: subCategoryBreakdown,
        monthlyBreakdown: monthlyBreakdown,
        monthlyBudget: monthlyBudget
      },
      entries: recentFlatEntries,
      receipts: receiptsList,
      metadata: getAppMetadata(customSpreadsheetId)
    };
  } catch (err) {
    Logger.log("Error getRecentEntries: " + err.toString());
    return {
      success: false,
      message: err.message,
      stats: { totalSpent: 0, totalItems: 0, thisMonthSpent: 0, dailyAverage: 0, categoryBreakdown: {}, monthlyBreakdown: {}, monthlyBudget: 0 },
      entries: [],
      receipts: [],
      metadata: null
    };
  }
}

/**
 * 10. AI VISION OCR: EKSTRAKSI MULTI-ITEM STRUK RUMAH TANGGA CERDAS (GEMINI 3.8 FLASH)
 */
function extractReceiptWithAI(payload) {
  try {
    if (!payload || (!payload.base64Data && !payload.textData)) {
      return { success: false, message: "Dokumen, foto struk, atau teks OCR tidak ditemukan." };
    }

    let apiKey = payload.userApiKey;
    if (!apiKey) {
      apiKey = PropertiesService.getScriptProperties().getProperty("GEMINI_API_KEY");
    }

    if (!apiKey) {
      return {
        success: false,
        needApiKey: true,
        message: "API Key Gemini belum disetel. Silakan masukkan API Key Gemini di menu Pengaturan."
      };
    }

    let contentParts = [];
    let mimeType = payload.mimeType || "image/jpeg";
    let rawBase64 = payload.base64Data || "";

    if (rawBase64 && rawBase64.indexOf("data:") === 0) {
      const parts = rawBase64.split(",");
      const meta = parts[0];
      const rawData = parts[1];
      const match = meta.match(/:(.*?);/);
      if (match && match[1]) {
        mimeType = match[1];
      }
      rawBase64 = rawData;
    }

    const masterCats = getMasterCategories();
    const categoriesPromptDesc = masterCats.map(c => 
      `- '${c.id}' (${c.name}): Subkategori mencakup [${(c.subCategories || []).join(", ")}]`
    ).join("\n");

    const systemPrompt = `Anda adalah asisten AI akuntansi keuangan rumah tangga cerdas untuk aplikasi "Saturuma" (Satu Rumah, Semua Pencatatan Terintegrasi).
Tugas Anda adalah membaca foto struk fisik, nota belanja kasir, invoice PDF, atau teks hasil OCR dokumen transaksi rumah tangga.
STRUK INI DAPAT BERISI SATU ATAU BANYAK BARANG (MULTI-ITEM), LENGKAP DENGAN DISKON DAN PAJAK/PPN.

DAFTAR MASTER KATEGORI RUMAH TANGGA YANG TERSEDIA:
${categoriesPromptDesc}

ATURAN PARSING:
1. Identifikasi Nama Toko / Merchant / Penyedia Layanan (contoh: Indomaret, Super Indo, PLN, Tokopedia, SPBU Pertamina).
2. Tentukan Tanggal Transaksi dalam format YYYY-MM-DD. Jika tidak terlihat, gunakan tanggal hari ini.
3. Tentukan "suggestedMasterCategoryId" dari salah satu ID kategori di atas: 'dapur', 'bayi', 'tagihan', 'tabungan', atau 'transport' yang paling cocok.
4. Identifikasi barang belanja pada struk ke array "items". JANGAN masukkan baris diskon/potongan atau pajak sebagai item nama barang!
5. Untuk setiap item:
   - "itemName": Nama spesifik dan jelas (contoh: Minyak Goreng Bimoli 2L, Beras Ramos 5kg, Popok MamyPoko M44, Bensin Pertalite).
   - "subCategory": Pilih subkategori yang paling relevan dari daftar di atas.
   - "qty": Jumlah unit/kuantitas (angka integer, default 1).
   - "cost": Total harga sebelum diskon untuk item tersebut (angka murni tanpa Rp atau titik).
6. Diskon, Pajak & Biaya Lainnya:
   - "discount": Nominal total potongan harga / promo / voucher pada struk (angka positif, 0 jika tidak ada).
   - "tax": Nominal pajak PPN / PB1 jika tercantum (angka positif, 0 jika tidak ada).
   - "other": Biaya lain-lain selain diskon dan pajak, seperti biaya layanan / jasa aplikasi / kantong belanja / ongkos kirim / tips / pembulatan (angka positif jika menambah biaya, atau negatif jika mengurangi, 0 jika tidak ada).
   - "grandTotal": Total akhir yang dibayar konsumen (angka murni).

Hasilkan JSON VALID MURNI tanpa format markdown atau kutipan teks lainnya:
{
  "merchant": "Nama Toko / Merchant",
  "date": "YYYY-MM-DD",
  "suggestedMasterCategoryId": "dapur",
  "items": [
    {
      "itemName": "Nama Barang Spesifik",
      "subCategory": "Sembako & Bumbu",
      "qty": 1,
      "cost": 35000
    }
  ],
  "subtotal": 35000,
  "discount": 0,
  "tax": 0,
  "other": 0,
  "grandTotal": 35000,
  "notes": "Catatan singkat struk"
}`;

    if (payload.textData) {
      // Pipeline Hybrid (OCR lokal teks -> AI)
      contentParts = [
        { text: systemPrompt + "\n\n--- TEKS STRUK HASIL OCR ---\n" + payload.textData }
      ];
    } else {
      // Full AI Vision (Visual foto / PDF langsung -> AI)
      contentParts = [
        { text: systemPrompt },
        {
          inlineData: {
            mimeType: mimeType,
            data: rawBase64
          }
        }
      ];
    }

    const requestBody = {
      contents: [
        {
          role: "user",
          parts: contentParts
        }
      ],
      generationConfig: {
        temperature: 0.1,
        responseMimeType: "application/json"
      }
    };

    const options = {
      method: "post",
      contentType: "application/json",
      headers: { "x-goog-api-key": apiKey },
      payload: JSON.stringify(requestBody),
      muteHttpExceptions: true
    };

    let candidateModels = [
      "gemini-3.8-flash",
      "gemini-3.8-flash-lite",
      "gemini-2.5-flash",
      "gemini-2.0-flash",
      "gemini-1.5-flash"
    ];

    if (payload.aiModel) {
      candidateModels = candidateModels.filter(m => m !== payload.aiModel);
      candidateModels.unshift(payload.aiModel);
    }

    let responseText = "";
    let responseCode = 0;
    let isSuccess = false;
    let usedModel = "";

    for (let m = 0; m < candidateModels.length && !isSuccess; m++) {
      const modelName = candidateModels[m];
      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${apiKey}`;

      for (let attempt = 0; attempt < 2; attempt++) {
        if (attempt > 0) Utilities.sleep(1000);
        try {
          const response = UrlFetchApp.fetch(apiUrl, options);
          responseCode = response.getResponseCode();
          responseText = response.getContentText();

          if (responseCode === 200) {
            isSuccess = true;
            usedModel = modelName;
            break;
          } else if (responseCode !== 503 && responseCode !== 429) {
            break;
          }
        } catch (fetchErr) {
          Logger.log("Fetch err for " + modelName + ": " + fetchErr.toString());
        }
      }
    }

    if (!isSuccess) {
      Logger.log("Gemini API Error (" + responseCode + "): " + responseText);
      return {
        success: false,
        message: "Gemini API Error (" + responseCode + "): Periksa koneksi atau kuota API Key Gemini Anda."
      };
    }

    const jsonResp = JSON.parse(responseText);
    const candidate = jsonResp.candidates && jsonResp.candidates[0];
    if (!candidate || !candidate.content || !candidate.content.parts) {
      return { success: false, message: "AI tidak dapat membaca teks dari struk." };
    }

    let aiText = "";
    const parts = candidate.content.parts || [];
    for (let p = parts.length - 1; p >= 0; p--) {
      if (parts[p].text && !parts[p].thought) {
        aiText = parts[p].text;
        break;
      }
    }
    if (!aiText && parts.length > 0) {
      aiText = parts[parts.length - 1].text || "";
    }

    aiText = aiText.trim();
    if (aiText.indexOf("```") !== -1) {
      aiText = aiText.replace(/```(?:json)?/gi, "").replace(/```/g, "").trim();
    }

    let extractedData;
    try {
      extractedData = JSON.parse(aiText);
    } catch (parseErr) {
      const firstBrace = aiText.indexOf("{");
      const lastBrace = aiText.lastIndexOf("}");
      if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
        extractedData = JSON.parse(aiText.substring(firstBrace, lastBrace + 1));
      } else {
        throw parseErr;
      }
    }

    if (!extractedData.items || !Array.isArray(extractedData.items) || extractedData.items.length === 0) {
      extractedData.items = [
        {
          itemName: extractedData.itemName || "Item Belanja Rumah Tangga",
          subCategory: extractedData.subCategory || "Lainnya",
          qty: 1,
          cost: extractedData.cost || extractedData.grandTotal || 0
        }
      ];
    }

    extractedData.discount = Number(extractedData.discount) || 0;
    extractedData.tax = Number(extractedData.tax) || 0;
    extractedData.other = Number(extractedData.other) || 0;

    return {
      success: true,
      message: `Berhasil mengekstrak ${extractedData.items.length} barang belanja dengan model ${usedModel || "Gemini 3.8 Flash"}!`,
      data: extractedData,
      usedModel: usedModel || "gemini-3.8-flash"
    };
  } catch (err) {
    Logger.log("Error extractReceiptWithAI: " + err.toString());
    return {
      success: false,
      message: "Gagal memproses struk dengan AI: " + err.message
    };
  }
}

/**
 * 11. PENGATURAN API KEY GEMINI & ANGGARAN BULANAN
 */
function saveGeminiApiKey(apiKey) {
  try {
    if (!apiKey || apiKey.trim() === "") {
      PropertiesService.getScriptProperties().deleteProperty("GEMINI_API_KEY");
      return { success: true, message: "Kunci API Gemini berhasil dihapus." };
    }
    PropertiesService.getScriptProperties().setProperty("GEMINI_API_KEY", apiKey.trim());
    return { success: true, message: "Kunci API Gemini berhasil disimpan!" };
  } catch (err) {
    return { success: false, message: err.message };
  }
}

function getGeminiApiKeyStatus() {
  const key = PropertiesService.getScriptProperties().getProperty("GEMINI_API_KEY");
  return {
    isConfigured: !!(key && key.length > 10),
    maskedKey: key ? (key.substring(0, 4) + "••••••••" + key.substring(key.length - 4)) : ""
  };
}

function saveMonthlyBudget(budget) {
  try {
    const num = Number(budget) || 0;
    PropertiesService.getScriptProperties().setProperty("MONTHLY_BUDGET", String(num));
    return { success: true, message: "Target anggaran bulanan berhasil disimpan!", monthlyBudget: num };
  } catch (err) {
    return { success: false, message: err.message };
  }
}

function getMonthlyBudget() {
  const val = PropertiesService.getScriptProperties().getProperty("MONTHLY_BUDGET");
  return Number(val) || 0;
}

/**
 * 12. METADATA APLIKASI SATURUMA
 */
function getAppMetadata(customId) {
  try {
    const ss = getSpreadsheetInstance(customId);
    const sheetUrl = ss ? ss.getUrl() : "";
    const folders = getStorageFolders();
    const driveFolderUrl = folders && folders.parent ? folders.parent.getUrl() : "";
    const monthlyBudget = getMonthlyBudget();
    const geminiKeyStatus = getGeminiApiKeyStatus();
    const categories = getMasterCategories();
    
    // Pastikan sheet pengguna (DB_Users) terinisialisasi
    try {
      initUsersSheet();
    } catch (uErr) {
      Logger.log("initUsersSheet pada getAppMetadata: " + uErr.toString());
    }

    return {
      success: true,
      appName: CONFIG.APP_NAME,
      appSlogan: CONFIG.APP_SLOGAN,
      spreadsheetUrl: sheetUrl,
      driveFolderUrl: driveFolderUrl,
      monthlyBudget: monthlyBudget,
      geminiKeyStatus: geminiKeyStatus,
      categories: categories,
      usersSheetName: CONFIG.USERS_SHEET_NAME,
      standardColumns: CONFIG.STANDARD_COLUMNS
    };
  } catch (err) {
    return {
      success: false,
      message: err.message,
      appName: CONFIG.APP_NAME,
      appSlogan: CONFIG.APP_SLOGAN,
      spreadsheetUrl: "",
      driveFolderUrl: "",
      monthlyBudget: 0,
      categories: CONFIG.DEFAULT_CATEGORIES,
      usersSheetName: CONFIG.USERS_SHEET_NAME,
      standardColumns: CONFIG.STANDARD_COLUMNS
    };
  }
}

/**
 * Sinkronisasi seluruh tab sheet transaksi ke format standar 14 kolom (termasuk kolom 'Other' / Biaya Lainnya)
 */
function syncSheetStructure(customId) {
  try {
    const ss = getSpreadsheetInstance(customId);
    const masterCats = getMasterCategories();
    const updatedSheets = [];

    // 1. Sinkronkan seluruh tab kategori yang terdaftar
    masterCats.forEach(cat => {
      const sh = getOrInitSheet(cat.sheetName, cat.color, customId);
      if (sh) updatedSheets.push(cat.sheetName);
    });

    // 2. Periksa sheet DB_ lainnya di spreadsheet
    const allSheets = ss.getSheets();
    allSheets.forEach(sh => {
      const name = sh.getName();
      if (name.indexOf("DB_") === 0 && name !== CONFIG.USERS_SHEET_NAME && !updatedSheets.includes(name)) {
        getOrInitSheet(name, "#10B981", customId);
        updatedSheets.push(name);
      }
    });

    return {
      success: true,
      message: `Berhasil menyinkronkan ${updatedSheets.length} tab sheet ke standar 14 kolom (termasuk kolom 'Other' / Biaya Lainnya).`,
      sheets: updatedSheets,
      columns: CONFIG.STANDARD_COLUMNS
    };
  } catch (err) {
    Logger.log("Error syncSheetStructure: " + err.toString());
    return {
      success: false,
      message: "Gagal menyinkronkan struktur sheet: " + err.message
    };
  }
}

/**
 * ============================================================================
 * 13. SISTEM KEAMANAN & OTENTIKASI PENGGUNA (DATABASE DB_Users)
 * "Penambahan pengguna hanya melalui database Google Sheets (DB_Users)"
 * - SHA-256 Cryptographic Salted Hashing
 * - Proteksi Brute-Force & Rate Limiting (Maks 5 percobaan gagal / 15 menit)
 * - Session Token Generator & Validator
 * - Auto-Hash Migration jika admin memasukkan password plaintext manual di sheet
 * ============================================================================
 */

/**
 * Inisialisasi sheet database pengguna DB_Users
 */
function initUsersSheet() {
  const ss = getSpreadsheetInstance();
  let sheet = ss.getSheetByName(CONFIG.USERS_SHEET_NAME);

  if (!sheet) {
    sheet = ss.insertSheet(CONFIG.USERS_SHEET_NAME);
  }

  // Pastikan kolom cukup untuk kolom pengguna (11 kolom)
  if (sheet.getMaxColumns() < CONFIG.USER_COLUMNS.length) {
    sheet.insertColumnsAfter(sheet.getMaxColumns(), CONFIG.USER_COLUMNS.length - sheet.getMaxColumns());
  }

  // Format Header jika masih kosong atau sinkronkan jika ada penambahan kolom
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(CONFIG.USER_COLUMNS);
    const headerRange = sheet.getRange(1, 1, 1, CONFIG.USER_COLUMNS.length);
    headerRange.setFontWeight("bold")
      .setBackground("#0F172A") // Dark Slate
      .setFontColor("#FFFFFF")
      .setHorizontalAlignment("center");
    sheet.setFrozenRows(1);
    sheet.autoResizeColumns(1, CONFIG.USER_COLUMNS.length);
  } else {
    // Sinkronkan header jika kolom bertambah
    const curCols = sheet.getLastColumn();
    if (curCols < CONFIG.USER_COLUMNS.length) {
      sheet.getRange(1, 1, 1, CONFIG.USER_COLUMNS.length).setValues([CONFIG.USER_COLUMNS]);
    }
  }

  // Jika belum ada data pengguna (hanya baris header), inisialisasi akun demo default: admin / admin 123
  if (sheet.getLastRow() <= 1) {
    const defaultSalt = generateSalt();
    const defaultHash = hashPasswordWithSalt(CONFIG.DEMO_USER.password, defaultSalt);
    const timeZone = Session.getScriptTimeZone() || "GMT+7";
    const nowStr = Utilities.formatDate(new Date(), timeZone, "yyyy-MM-dd HH:mm:ss");

    sheet.appendRow([
      "USR_0001",
      CONFIG.DEMO_USER.username,
      defaultHash,
      defaultSalt,
      CONFIG.DEMO_USER.fullName,
      CONFIG.DEMO_USER.role,
      "active",
      nowStr,
      "" // LastLogin
    ]);

    sheet.autoResizeColumns(1, CONFIG.USER_COLUMNS.length);
    Logger.log("Akun demo default dibuat di sheet DB_Users (username: admin, role: admin)");
  }

  return sheet;
}

/**
 * Peta Nama Tampilan Pengguna (UserID / Username -> FullName / Display Name)
 * Digunakan untuk menampilkan identitas pencatat pada arsitektur 1 database kolaboratif
 */
function getUserDisplayNameMap() {
  const map = {};
  try {
    const sheet = initUsersSheet();
    const data = sheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      const uId = String(data[i][0] || "").trim();
      const uName = String(data[i][1] || "").trim();
      const fName = String(data[i][4] || "").trim();
      const displayName = fName || uName;
      if (uId) map[uId] = displayName;
      if (uName) map[uName] = displayName;
    }
  } catch (err) {
    Logger.log("getUserDisplayNameMap error: " + err.toString());
  }
  return map;
}

/**
 * Generator Salt Kriptografis Acak
 */
function generateSalt() {
  const uuid = Utilities.getUuid().replace(/-/g, "");
  const time = Date.now().toString(16);
  return (uuid + time).substring(0, 16);
}

/**
 * Menghitung Hash Password dengan Salt (SHA-256)
 * Salt + Secret Pepper + Password -> SHA-256 Hex
 */
function hashPasswordWithSalt(password, salt) {
  if (password === null || password === undefined || password === "") return "";
  const pepper = "#saturuma_secure_auth_pepper_2026#";
  const rawString = String(salt || "") + "::" + pepper + "::" + String(password).trim();
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, rawString, Utilities.Charset.UTF_8);
  
  let hex = "";
  for (let i = 0; i < digest.length; i++) {
    let b = digest[i];
    if (b < 0) b += 256;
    let s = b.toString(16);
    if (s.length === 1) s = "0" + s;
    hex += s;
  }
  return hex;
}

/**
 * Perbandingan String Waktu Konstan (Mencegah Serangan Timing Attack)
 */
function safeStringCompare(a, b) {
  if (typeof a !== "string" || typeof b !== "string") return false;
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return result === 0;
}

/**
 * Pemeriksaan Rate Limiting & Penguncian Akun Brute-Force
 */
function checkLoginRateLimit(username) {
  try {
    const cache = CacheService.getScriptCache();
    const cleanUser = String(username || "").toLowerCase().trim();
    const lockKey = "USER_LOCKOUT_" + cleanUser;
    const lockedUntil = cache.get(lockKey);

    if (lockedUntil) {
      const msLeft = Number(lockedUntil) - Date.now();
      if (msLeft > 0) {
        const minLeft = Math.max(1, Math.ceil(msLeft / 60000));
        return {
          isLocked: true,
          message: `Akun terkunci sementara karena 5 kali percobaan login gagal. Silakan coba lagi dalam ${minLeft} menit.`
        };
      } else {
        cache.remove(lockKey);
      }
    }
  } catch (err) {
    Logger.log("checkLoginRateLimit error: " + err.toString());
  }
  return { isLocked: false };
}

/**
 * Catat Percobaan Login Gagal
 */
function recordFailedLoginAttempt(username) {
  try {
    const cache = CacheService.getScriptCache();
    const cleanUser = String(username || "").toLowerCase().trim();
    const countKey = "USER_ATTEMPTS_" + cleanUser;
    const lockKey = "USER_LOCKOUT_" + cleanUser;

    const current = Number(cache.get(countKey) || 0) + 1;

    if (current >= 5) {
      // Kunci selama 15 menit (900 detik)
      cache.put(lockKey, String(Date.now() + 15 * 60 * 1000), 900);
      cache.remove(countKey);
      return {
        locked: true,
        message: "Akun dikunci sementara selama 15 menit karena 5 kali percobaan login salah berturut-turut demi keamanan."
      };
    } else {
      // Simpan riwayat percobaan selama 10 menit
      cache.put(countKey, String(current), 600);
      const remaining = 5 - current;
      return {
        locked: false,
        message: `Username atau password salah! Sisa percobaan: ${remaining} kali sebelum akun dikunci.`
      };
    }
  } catch (err) {
    return { locked: false, message: "Username atau password salah." };
  }
}

/**
 * Reset Percobaan Login Gagal setelah Login Sukses
 */
function resetLoginAttempts(username) {
  try {
    const cache = CacheService.getScriptCache();
    const cleanUser = String(username || "").toLowerCase().trim();
    cache.remove("USER_ATTEMPTS_" + cleanUser);
    cache.remove("USER_LOCKOUT_" + cleanUser);
  } catch (err) {}
}

/**
 * VERIFIKASI LOGIN PENGGUNA
 * Menerima username & password dari klien
 * Mendukung password demo "admin 123" dan "admin123"
 * Mendukung migrasi instan jika admin mengetikkan password plaintext langsung di database sheet!
 */
function verifyUserLogin(username, password) {
  try {
    const cleanUser = String(username || "").trim();
    const cleanPass = String(password || "").trim();

    if (!cleanUser || !cleanPass) {
      return {
        success: false,
        message: "Username dan password wajib diisi."
      };
    }

    // 1. Cek Rate Limiting / Proteksi Brute Force
    const rateCheck = checkLoginRateLimit(cleanUser);
    if (rateCheck.isLocked) {
      return {
        success: false,
        message: rateCheck.message,
        isLocked: true
      };
    }

    // 2. Ambil data dari sheet database DB_Users
    const sheet = initUsersSheet();
    const data = sheet.getDataRange().getValues();

    if (data.length <= 1) {
      return {
        success: false,
        message: "Database pengguna belum tersedia. Silakan muat ulang halaman."
      };
    }

    let userRowIndex = -1;
    let matchedUser = null;

    // Header: UserID(0), Username(1), PasswordHash(2), Salt(3), FullName(4), Role(5), Status(6), CreatedAt(7), LastLogin(8)
    for (let i = 1; i < data.length; i++) {
      const rowUser = String(data[i][1] || "").trim();
      if (rowUser.toLowerCase() === cleanUser.toLowerCase()) {
        userRowIndex = i + 1; // 1-based index untuk range
        matchedUser = {
          rowIndex: userRowIndex,
          userId: String(data[i][0] || "USR_" + i),
          username: rowUser,
          storedHash: String(data[i][2] || "").trim(),
          storedSalt: String(data[i][3] || "").trim(),
          fullName: String(data[i][4] || rowUser),
          role: String(data[i][5] || "user").toLowerCase(),
          status: String(data[i][6] || "active").toLowerCase(),
          createdAt: String(data[i][7] || ""),
          lastLogin: String(data[i][8] || ""),
          customSpreadsheetId: String(data[i][9] || "").trim(),
          geminiApiKey: String(data[i][10] || "").trim()
        };
        break;
      }
    }

    // 3. Jika pengguna tidak ditemukan
    if (!matchedUser) {
      const failInfo = recordFailedLoginAttempt(cleanUser);
      return {
        success: false,
        message: failInfo.message
      };
    }

    // 4. Periksa status keaktifan akun
    if (matchedUser.status !== "active") {
      return {
        success: false,
        message: "Akun ini telah dinonaktifkan oleh administrator. Hubungi pemilik sistem."
      };
    }

    // 5. Validasi Kata Sandi
    let isPasswordValid = false;
    let needsHashUpgrade = false;

    // Skenario A: Admin menambahkan user baru langsung di sheet dengan teks biasa (atau salt kosong)
    const isPlaintextStored = !matchedUser.storedSalt || matchedUser.storedHash.length !== 64;

    if (isPlaintextStored) {
      // Jika di database berupa plaintext, cocokkan langsung
      if (cleanPass === matchedUser.storedHash) {
        isPasswordValid = true;
        needsHashUpgrade = true;
      } else if (cleanUser.toLowerCase() === "admin" && (cleanPass === "admin 123" || cleanPass === "admin123")) {
        // Toleransi format demo admin
        isPasswordValid = true;
        needsHashUpgrade = true;
      }
    } else {
      // Skenario B: Password sudah ter-hash SHA-256 dengan Salt
      const computedHash = hashPasswordWithSalt(cleanPass, matchedUser.storedSalt);
      if (safeStringCompare(computedHash, matchedUser.storedHash)) {
        isPasswordValid = true;
      } else if (cleanUser.toLowerCase() === "admin") {
        // Toleransi spasi untuk demo password admin ("admin 123" vs "admin123")
        const altDemo = cleanPass === "admin 123" ? "admin123" : (cleanPass === "admin123" ? "admin 123" : null);
        if (altDemo && safeStringCompare(hashPasswordWithSalt(altDemo, matchedUser.storedSalt), matchedUser.storedHash)) {
          isPasswordValid = true;
        }
      }
    }

    // 6. Jika Password Salah
    if (!isPasswordValid) {
      const failInfo = recordFailedLoginAttempt(cleanUser);
      return {
        success: false,
        message: failInfo.message
      };
    }

    // 7. Jika Valid, bersihkan counter gagal
    resetLoginAttempts(cleanUser);

    // 8. Auto-Upgrade Hash jika sebelumnya berupa plaintext di sheet
    let currentSalt = matchedUser.storedSalt;
    let currentHash = matchedUser.storedHash;
    if (needsHashUpgrade) {
      currentSalt = generateSalt();
      currentHash = hashPasswordWithSalt(cleanPass, currentSalt);
      sheet.getRange(matchedUser.rowIndex, 3).setValue(currentHash); // Col 3: PasswordHash
      sheet.getRange(matchedUser.rowIndex, 4).setValue(currentSalt); // Col 4: Salt
      Logger.log("Auto-Hash Migration: Password plaintext untuk pengguna '" + cleanUser + "' berhasil diamankan ke SHA-256!");
    }

    // 9. Update Kolom LastLogin di Spreadsheet
    const timeZone = Session.getScriptTimeZone() || "GMT+7";
    const nowStr = Utilities.formatDate(new Date(), timeZone, "yyyy-MM-dd HH:mm:ss");
    sheet.getRange(matchedUser.rowIndex, 9).setValue(nowStr); // Col 9: LastLogin

    // 10. Terbitkan Token Sesi Kriptografis
    const sessionToken = Utilities.base64EncodeWebSafe(
      Utilities.getUuid() + "_" + Date.now() + "_" + matchedUser.userId
    );

    const userPayload = {
      userId: matchedUser.userId,
      username: matchedUser.username,
      fullName: matchedUser.fullName,
      role: matchedUser.role,
      lastLogin: nowStr,
      customSpreadsheetId: matchedUser.customSpreadsheetId || "",
      customSpreadsheetUrl: matchedUser.customSpreadsheetId ? ("https://docs.google.com/spreadsheets/d/" + matchedUser.customSpreadsheetId) : "",
      geminiApiKey: matchedUser.geminiApiKey || ""
    };

    // Simpan sesi di CacheService (Masa aktif max GAS = 21600 detik / 6 jam)
    try {
      const cache = CacheService.getScriptCache();
      cache.put("AUTH_SESS_" + sessionToken, JSON.stringify(userPayload), 21600);
    } catch (cacheErr) {
      Logger.log("Cache session error: " + cacheErr.toString());
    }

    return {
      success: true,
      message: `Login berhasil! Selamat datang kembali, ${matchedUser.fullName}.`,
      sessionToken: sessionToken,
      user: userPayload
    };

  } catch (err) {
    Logger.log("Error verifyUserLogin: " + err.toString());
    return {
      success: false,
      message: "Terjadi kesalahan sistem saat memproses login: " + err.message
    };
  }
}

/**
 * Validasi Token Sesi Pengguna (dengan Resilient Fallback ke DB_Users)
 */
function validateSession(sessionToken) {
  if (!sessionToken || typeof sessionToken !== "string") {
    return { success: false, message: "Token sesi tidak valid." };
  }

  try {
    const cache = CacheService.getScriptCache();
    const raw = cache.get("AUTH_SESS_" + sessionToken);
    if (raw) {
      const user = JSON.parse(raw);
      return { success: true, user: user };
    }

    // Fallback: Jika cache ter-evict atau kedaluwarsa 6 jam, verifikasi kriptografis token
    // Format token: base64(uuid + "_" + timestamp + "_" + userId)
    try {
      const decoded = Utilities.newBlob(Utilities.base64DecodeWebSafe(sessionToken)).getDataAsString();
      const parts = decoded.split("_");
      if (parts.length >= 3) {
        const tokenTime = Number(parts[1]);
        const tokenUserId = parts.slice(2).join("_");
        // Berikan masa aktif token hingga 7 hari
        const maxAgeMs = 7 * 24 * 3600 * 1000;
        if (Date.now() - tokenTime < maxAgeMs) {
          const sheet = initUsersSheet();
          const data = sheet.getDataRange().getValues();
          for (let i = 1; i < data.length; i++) {
            if (String(data[i][0] || "") === tokenUserId && String(data[i][6] || "").toLowerCase() === "active") {
              const userPayload = {
                userId: String(data[i][0]),
                username: String(data[i][1]),
                fullName: String(data[i][4] || data[i][1]),
                role: String(data[i][5] || "user").toLowerCase(),
                customSpreadsheetId: String(data[i][9] || "").trim(),
                customSpreadsheetUrl: data[i][9] ? ("https://docs.google.com/spreadsheets/d/" + data[i][9]) : "",
                geminiApiKey: String(data[i][10] || "").trim()
              };
              // Refresh kembali cache sesi
              try {
                cache.put("AUTH_SESS_" + sessionToken, JSON.stringify(userPayload), 21600);
              } catch(e) {}
              return { success: true, user: userPayload };
            }
          }
        }
      }
    } catch (fallbackErr) {
      Logger.log("Session fallback error: " + fallbackErr.toString());
    }

    return { success: false, message: "Sesi telah berakhir atau kedaluwarsa. Silakan login kembali." };
  } catch (err) {
    return { success: false, message: "Validasi sesi gagal: " + err.message };
  }
}

/**
 * Logout Pengguna / Hancurkan Sesi
 */
function logoutUser(sessionToken) {
  try {
    if (sessionToken) {
      const cache = CacheService.getScriptCache();
      cache.remove("AUTH_SESS_" + sessionToken);
    }
    return { success: true, message: "Berhasil keluar dari sistem." };
  } catch (err) {
    return { success: true, message: "Sesi telah diakhiri." };
  }
}

/**
 * Ubah Password Pengguna yang Sedang Login
 */
function changeCurrentUserPassword(sessionToken, oldPassword, newPassword) {
  try {
    const sessResult = validateSession(sessionToken);
    if (!sessResult.success) {
      return { success: false, message: "Sesi tidak valid atau telah kedaluwarsa." };
    }

    const username = sessResult.user.username;
    if (!newPassword || String(newPassword).trim().length < 6) {
      return { success: false, message: "Password baru minimal harus terdiri dari 6 karakter." };
    }

    const sheet = initUsersSheet();
    const data = sheet.getDataRange().getValues();

    let userRowIndex = -1;
    let storedHash = "";
    let storedSalt = "";

    for (let i = 1; i < data.length; i++) {
      if (String(data[i][1] || "").toLowerCase() === username.toLowerCase()) {
        userRowIndex = i + 1;
        storedHash = String(data[i][2] || "").trim();
        storedSalt = String(data[i][3] || "").trim();
        break;
      }
    }

    if (userRowIndex === -1) {
      return { success: false, message: "Pengguna tidak ditemukan dalam database." };
    }

    // Verifikasi password lama
    let isOldValid = false;
    if (!storedSalt || storedHash.length !== 64) {
      isOldValid = (oldPassword === storedHash) || (username.toLowerCase() === "admin" && (oldPassword === "admin 123" || oldPassword === "admin123"));
    } else {
      isOldValid = safeStringCompare(hashPasswordWithSalt(oldPassword, storedSalt), storedHash);
      if (!isOldValid && username.toLowerCase() === "admin") {
        const altOld = oldPassword === "admin 123" ? "admin123" : (oldPassword === "admin123" ? "admin 123" : null);
        if (altOld && safeStringCompare(hashPasswordWithSalt(altOld, storedSalt), storedHash)) {
          isOldValid = true;
        }
      }
    }

    if (!isOldValid) {
      return { success: false, message: "Password lama tidak sesuai." };
    }

    // Generate Salt & Hash baru
    const newSalt = generateSalt();
    const newHash = hashPasswordWithSalt(newPassword, newSalt);

    sheet.getRange(userRowIndex, 3).setValue(newHash);
    sheet.getRange(userRowIndex, 4).setValue(newSalt);

    return { success: true, message: "Password berhasil diperbarui dengan aman!" };
  } catch (err) {
    return { success: false, message: "Gagal mengubah password: " + err.message };
  }
}

/**
 * HELPER UNTUK ADMINISTRATOR: Tambah User Langsung via Skrip / Macro
 * (Memenuhi syarat: penambahan user hanya melalui database oleh pengelola sistem)
 */
function adminCreateUserDirectly(username, password, fullName, role) {
  try {
    const cleanUser = String(username || "").trim();
    const cleanPass = String(password || "").trim();
    if (!cleanUser || !cleanPass) {
      throw new Error("Username dan password tidak boleh kosong.");
    }

    const sheet = initUsersSheet();
    const data = sheet.getDataRange().getValues();

    for (let i = 1; i < data.length; i++) {
      if (String(data[i][1] || "").toLowerCase() === cleanUser.toLowerCase()) {
        throw new Error(`Username '${cleanUser}' sudah terdaftar dalam database!`);
      }
    }

    const salt = generateSalt();
    const hash = hashPasswordWithSalt(cleanPass, salt);
    const timeZone = Session.getScriptTimeZone() || "GMT+7";
    const nowStr = Utilities.formatDate(new Date(), timeZone, "yyyy-MM-dd HH:mm:ss");
    const newUserId = "USR_" + Utilities.formatDate(new Date(), timeZone, "yyMMdd_HHmmss");

    sheet.appendRow([
      newUserId,
      cleanUser,
      hash,
      salt,
      fullName || cleanUser,
      role || "user",
      "active",
      nowStr,
      ""
    ]);

    return {
      success: true,
      message: `Pengguna '${cleanUser}' berhasil didaftarkan ke database sheet DB_Users!`,
      userId: newUserId
    };
  } catch (err) {
    return { success: false, message: err.message };
  }
}

/**
 * 14. PENDAFTARAN PENGGUNA BARU (REGISTRASI MULTI-USER & DEDICATED SPREADSHEET)
 * Mendukung penyimpanan ke spreadsheet pribadi (BYOD) atau database utama
 */
function registerUser(payload) {
  try {
    if (!payload) return { success: false, message: "Data registrasi tidak lengkap." };
    const username = String(payload.username || "").trim();
    const password = String(payload.password || "").trim();
    const fullName = String(payload.fullName || username).trim();
    const customSpreadsheetUrl = String(payload.customSpreadsheetUrl || "").trim();
    const geminiApiKey = String(payload.geminiApiKey || "").trim();

    if (!username || username.length < 3) {
      return { success: false, message: "Username minimal 3 karakter (tanpa spasi)." };
    }
    if (!password || password.length < 4) {
      return { success: false, message: "Kata sandi minimal 4 karakter." };
    }

    const sheet = initUsersSheet();
    const data = sheet.getDataRange().getValues();

    // Periksa apakah username sudah terdaftar
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][1] || "").toLowerCase() === username.toLowerCase()) {
        return { success: false, message: "Username '" + username + "' sudah digunakan. Silakan pilih username lain." };
      }
    }

    // Inisialisasi dedicated spreadsheet pribadi jika diisi
    let cleanSpreadsheetId = "";
    if (customSpreadsheetUrl) {
      cleanSpreadsheetId = extractSpreadsheetId(customSpreadsheetUrl);
      try {
        const targetSs = SpreadsheetApp.openById(cleanSpreadsheetId);
        // Otomatis buat sheet-sheet kategori transaksi di spreadsheet user tersebut jika belum ada
        CONFIG.DEFAULT_CATEGORIES.forEach(cat => {
          let catSheet = targetSs.getSheetByName(cat.sheetName);
          if (!catSheet) {
            catSheet = targetSs.insertSheet(cat.sheetName);
            catSheet.appendRow(CONFIG.STANDARD_COLUMNS);
            catSheet.getRange(1, 1, 1, CONFIG.STANDARD_COLUMNS.length)
              .setFontWeight("bold")
              .setBackground(cat.color || "#10B981")
              .setFontColor("#ffffff")
              .setHorizontalAlignment("center");
            catSheet.setFrozenRows(1);
          }
        });
      } catch (accessErr) {
        return {
          success: false,
          message: "Gagal menghubungkan Google Sheets pribadi: " + accessErr.message + ". Pastikan spreadsheet telah diset izin 'Anyone with link can edit' atau bagikan ke email pengelola."
        };
      }
    }

    const salt = generateSalt();
    const hash = hashPasswordWithSalt(password, salt);
    const timeZone = Session.getScriptTimeZone() || "GMT+7";
    const nowStr = Utilities.formatDate(new Date(), timeZone, "yyyy-MM-dd HH:mm:ss");
    const newUserId = "USR_" + Utilities.formatDate(new Date(), timeZone, "yyMMdd_HHmmss");

    sheet.appendRow([
      newUserId,
      username,
      hash,
      salt,
      fullName,
      "member",
      "active",
      nowStr,
      nowStr, // LastLogin
      cleanSpreadsheetId,
      geminiApiKey
    ]);

    // Terbitkan token sesi agar user langsung otomatis login setelah pendaftaran berhasil
    const sessionToken = Utilities.base64EncodeWebSafe(
      Utilities.getUuid() + "_" + Date.now() + "_" + newUserId
    );

    const userPayload = {
      userId: newUserId,
      username: username,
      fullName: fullName,
      role: "member",
      lastLogin: nowStr,
      customSpreadsheetId: cleanSpreadsheetId,
      customSpreadsheetUrl: cleanSpreadsheetId ? ("https://docs.google.com/spreadsheets/d/" + cleanSpreadsheetId) : "",
      geminiApiKey: geminiApiKey
    };

    try {
      const cache = CacheService.getScriptCache();
      cache.put("AUTH_SESS_" + sessionToken, JSON.stringify(userPayload), 21600);
    } catch (cacheErr) {
      Logger.log("Cache register error: " + cacheErr.toString());
    }

    return {
      success: true,
      message: "Registrasi berhasil! Selamat datang di Saturuma, " + fullName + "!",
      sessionToken: sessionToken,
      user: userPayload
    };
  } catch (err) {
    Logger.log("Error registerUser: " + err.toString());
    return { success: false, message: "Terjadi kesalahan saat registrasi: " + err.message };
  }
}

/**
 * RECOVERY HELPER: Reset Akun Admin Default & Buka Lockout
 * Pilih fungsi ini di toolbar Apps Script lalu klik "Run" jika terkunci atau lupa password!
 */
function resetAdminLogin() {
  const ss = getSpreadsheetInstance();
  let sheet = ss.getSheetByName(CONFIG.USERS_SHEET_NAME);
  if (!sheet) {
    sheet = initUsersSheet();
  }

  const defaultUser = "admin";
  const defaultPass = "admin 123";
  const salt = generateSalt();
  const hash = hashPasswordWithSalt(defaultPass, salt);
  const timeZone = Session.getScriptTimeZone() || "GMT+7";
  const nowStr = Utilities.formatDate(new Date(), timeZone, "yyyy-MM-dd HH:mm:ss");

  const data = sheet.getDataRange().getValues();
  let found = false;
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][1] || "").toLowerCase() === defaultUser) {
      sheet.getRange(i + 1, 3).setValue(hash); // Col 3: PasswordHash
      sheet.getRange(i + 1, 4).setValue(salt); // Col 4: Salt
      sheet.getRange(i + 1, 7).setValue("active"); // Col 7: Status
      found = true;
      Logger.log("Akun admin di baris " + (i + 1) + " berhasil direset!");
      break;
    }
  }

  if (!found) {
    sheet.appendRow([
      "USR_0001",
      defaultUser,
      hash,
      salt,
      "Administrator Saturuma",
      "admin",
      "active",
      nowStr,
      ""
    ]);
    Logger.log("Baris akun admin baru berhasil dibuat di sheet DB_Users!");
  }

  // Bersihkan lockout cache jika sebelumnya terkunci
  try {
    const cache = CacheService.getScriptCache();
    cache.remove("USER_LOCKOUT_" + defaultUser);
    cache.remove("FAILED_LOGIN_" + defaultUser);
  } catch (cacheErr) {
    Logger.log("Reset cache error: " + cacheErr.toString());
  }

  Logger.log("=================================================");
  Logger.log("✅ RESET AKUN ADMIN SUKSES!");
  Logger.log("Username: admin");
  Logger.log("Password: admin 123");
  Logger.log("Spreadsheet URL: " + ss.getUrl());
  Logger.log("=================================================");

  return {
    success: true,
    message: "Akun admin berhasil direset. Silakan login dengan 'admin' dan 'admin 123'.",
    spreadsheetUrl: ss.getUrl()
  };
}
